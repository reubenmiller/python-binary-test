import warnings

warnings.warn('module-level warning', DeprecationWarning, stacklevel=2)
